package com.example.demo.service;

import java.awt.List;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.util.IOUtils;

@Service
public class S3Service implements FileServiceImpl {
 String bucket1 ="testkhadija";
	private AmazonS3 S3;
	
	@Value("${access-key}")
	private String accessKey;

	@Value("${secret-key}")
	private String secretKey; 

	@Value("${region}")
	private String region;
	@SuppressWarnings("deprecation")
	@PostConstruct
	private void initializeAmazon(){
	AWSCredentials credentials = new BasicAWSCredentials(this.accessKey,this.secretKey);
	this.S3 = new AmazonS3Client(credentials);
	S3.createBucket(bucket1);
	}
	

 
// upload File

	public String saveFile(MultipartFile file) {

		String originalFilename = file.getOriginalFilename();

		try {
			File file1 = convertMultiPartToFile(file);
			PutObjectResult putObjectResult = S3.putObject(bucket1, originalFilename, file1);
			return putObjectResult.getContentMd5();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

	}

	public byte[] downloadFile(String filename) {
		S3Object object = S3.getObject(bucket1, filename);
		S3ObjectInputStream objectContent = object.getObjectContent();
		try {
			return IOUtils.toByteArray(objectContent);
		} catch (IOException e) {
			throw new RuntimeException(e);

		}

	}


	public String deleteFile(String filename) {
		S3.deleteObject(bucket1, filename);
		return "file deleted";
	}

	
	public List listallFill() {
		ListObjectsV2Result listObjectV2Result = S3.listObjectsV2(bucket1);
		return (List) listObjectV2Result.getObjectSummaries().stream().map(S3ObjectSummary::getKey)
				.collect(Collectors.toList());

	}

	private File convertMultiPartToFile(MultipartFile file) throws IOException {
		File convFile = new File(file.getOriginalFilename());
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}

}
