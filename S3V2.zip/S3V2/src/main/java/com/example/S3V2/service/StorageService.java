package com.example.S3V2.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.core.async.AsyncRequestBody;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3AsyncClient;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.ObjectCannedACL;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;
import software.amazon.awssdk.utils.IoUtils;

@Service
public class StorageService {
	@Autowired
	private S3Client s3Client;
	@Autowired
	private String bucketName;
	@Autowired
	S3AsyncClient s3AsyncClient;

	// upload file ***********

	public String uploadFile(MultipartFile file) {
		File fileObj = convertMultiPartFileToFile(file);
		String fileName = file.getOriginalFilename();

		PutObjectRequest putObjectRequest = PutObjectRequest.builder()
				.bucket(this.bucketName)
				.key(fileName) // uniquely identifies the object in an Amazon S3 bucket.
				.build();

		this.s3Client.putObject(putObjectRequest, RequestBody.fromFile(fileObj));

		return "Your file " + fileName + " was successfully uploaded.";
	}

	// upload file <asynchrone>**********
	public String uploadFileAsync(MultipartFile file) {
		String fileName = file.getOriginalFilename();

		PutObjectRequest objectRequest = PutObjectRequest.builder()
				.bucket(bucketName)
				.key(fileName)
				.build();

		// Put the object into the bucket
		CompletableFuture<PutObjectResponse> future = s3AsyncClient.putObject(objectRequest,
				AsyncRequestBody.fromFile(Paths.get(fileName)));
		future.whenComplete((resp, err) -> {
			try {
				if (resp != null) {
					System.out.println("Object uploaded. Details: " + resp);
				} else {
					// Handle error
					err.printStackTrace();
				}
			} finally {
				// Only close the client when we are completely done with it
				// s3Client.close();
			}
		});

		future.join();

		return "Your file " + fileName + " was successfully uploaded ASync";
	}

	// Download File ***********************************

	public byte[] downloadFile(String fileName) {
		GetObjectRequest getObjectRequest = GetObjectRequest.builder()
				.bucket(this.bucketName)
				.key(fileName) // uniquely identifies the object in an Amazon S3 bucket.
				.build();

		ResponseInputStream<GetObjectResponse> inputStream = s3Client.getObject(getObjectRequest);

		try {
			byte[] content = IoUtils.toByteArray(inputStream);
			return content;
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;
	}

	// Delete File ***********************************
	public String deleteFile(String fileName) {
		DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest.builder()
				.bucket(this.bucketName)
				.key(fileName) // uniquely identifies the object in an Amazon S3 bucket.
				.build();

		s3Client.deleteObject(deleteObjectRequest);

		return "Your file " + fileName + " was successfully deleted.";
	}

	// Convert File *************************************
	private File convertMultiPartFileToFile(MultipartFile file) {
		File convertedFile = new File(file.getOriginalFilename());
		try (FileOutputStream fos = new FileOutputStream(convertedFile)) {
			fos.write(file.getBytes());
		} catch (IOException e) {

			System.out.println("Error converting multipartFile to file");
			throw new RuntimeException(e);
		}
		return convertedFile;
	}

	// saveRepertoire version 2 + filewalk + S3ClientAsync *********************************************

	public String uploadFolder1(Path filePath) {

		PutObjectRequest objectRequest = PutObjectRequest.builder()
				.bucket(bucketName)
				.key(filePath.getFileName().toString())
				.build();

		// Put the object into the bucket
		CompletableFuture<PutObjectResponse> future = s3AsyncClient.putObject(objectRequest,
				AsyncRequestBody.fromFile(filePath));
		future.whenComplete((resp, err) -> {
			try {
				if (resp != null) {
					System.out.println("Object uploaded. Details: " + resp);
				} else {
					err.printStackTrace();
				}
			} finally {

				// s3Client.close();
			}
		});

		future.join();

		return "Your file " + filePath + " was successfully uploaded ASync";
	}

	public void saverepertoire2(String path) throws IOException {
		Path path1 = Paths.get(path);
		try (Stream<Path> paths = Files.walk(path1)) {
			paths.filter(Files::isRegularFile).forEach(x -> uploadFolder1(x));
		}
	}

	// *********************************************************************************
	public CompletableFuture<Path> write(String name) {

		Path file = Paths.get(name);
		PutObjectRequest request = PutObjectRequest.builder()
				.bucket(bucketName)
				.key(file.getFileName().toString())
				.acl(ObjectCannedACL.BUCKET_OWNER_FULL_CONTROL)
				.build();
		return s3AsyncClient.putObject(request, AsyncRequestBody.fromFile(file.toFile()))
				.thenApply(response -> {
					return file;
				}).exceptionally(err -> {
					return null;
				});
	}
	// **********************************************************************************

	public void upload(String folderName) {
		PutObjectRequest request = PutObjectRequest.builder().bucket(bucketName).key(folderName).build();
		s3Client.putObject(request, RequestBody.empty());

	}
}
