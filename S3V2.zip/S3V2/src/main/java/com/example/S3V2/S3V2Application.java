package com.example.S3V2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S3V2Application {

	public static void main(String[] args) {
		SpringApplication.run(S3V2Application.class, args);
	}

}
