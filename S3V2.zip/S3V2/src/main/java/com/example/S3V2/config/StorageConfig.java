package com.example.S3V2.config;

import java.net.URI;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3AsyncClient;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.CreateBucketRequest;

@Configuration
public class StorageConfig {
	@Value("${access-key}")
	private String accessKey;
	@Value("${secret-key}")
	private String secretAccessKey;
	@Value("${region}")
	private String region;
	@Value("${endPoint}")
	private String endpoint;
	S3Client s3;
	S3AsyncClient s3AsyncClient;

	String bucketName = "bucketest";

	// S3Client***************************
	@Bean
	S3Client s3Client() {
		AwsCredentials credentials = AwsBasicCredentials.create(accessKey, secretAccessKey);
		Region region = Region.of(this.region);

		s3 = S3Client.builder()
				.credentialsProvider(StaticCredentialsProvider.create(credentials))
				.region(region)
				.endpointOverride(URI.create(endpoint))
				.build();
		CreateBucketRequest request = CreateBucketRequest.builder().bucket(bucketName).build();
		s3.createBucket(request);
		return s3;
	}

//S3AsynClient**************************

	@Bean
	S3AsyncClient S3AsyncClient() {
		AwsCredentials credentials = AwsBasicCredentials.create(accessKey, secretAccessKey);
		Region region = Region.of(this.region);

		s3AsyncClient = S3AsyncClient.builder()
				.credentialsProvider(StaticCredentialsProvider.create(credentials))
				.region(region)
				.endpointOverride(URI.create(endpoint))
				.build();
		CreateBucketRequest request = CreateBucketRequest.builder().bucket(bucketName).build();
		s3AsyncClient.createBucket(request);
		return s3AsyncClient;
	}

	@Bean
	public String s3BucketName() {
		return this.bucketName;
	}
}
